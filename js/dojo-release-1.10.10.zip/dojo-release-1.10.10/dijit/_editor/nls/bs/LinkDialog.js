//>>built
define("dijit/_editor/nls/bs/LinkDialog",{createLinkTitle:"Osobine povezivanja",insertImageTitle:"Osobine slike",url:"URL:",text:"Opis",target:"Cilj:",set:"Postav",currentWindow:"Trenutni prozor",parentWindow:"Nadređeni prozor",topWindow:"Najviši prozor",newWindow:"Novi prozor"});
