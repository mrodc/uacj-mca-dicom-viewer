define("dijit/_editor/nls/bs/LinkDialog", {      
//begin v1.x content
	createLinkTitle: "Osobine povezivanja",
	insertImageTitle: "Osobine slike",
	url: "URL:",
	text: "Opis",
	target: "Cilj:",
	set: "Postav",
	currentWindow: "Trenutni prozor",
	parentWindow: "Nadređeni prozor",
	topWindow: "Najviši prozor",
	newWindow: "Novi prozor"
//end v1.x content
});

