define("dijit/_editor/nls/eu/LinkDialog", {      
//begin v1.x content
	createLinkTitle: "Estekaren propietateak",
	insertImageTitle: "Irudiaren propietateak",
	url: "URLa:",
	text: "Azalpena:",
	target: "Helburua:",
	set: "Ezarri",
	currentWindow: "Uneko leihoa",
	parentWindow: "Leiho gurasoa",
	topWindow: "Goi-goiko leihoa",
	newWindow: "Leiho berria"
//end v1.x content
});

