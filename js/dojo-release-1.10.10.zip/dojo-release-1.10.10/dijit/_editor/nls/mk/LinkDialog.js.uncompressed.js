define("dijit/_editor/nls/mk/LinkDialog", {      
//begin v1.x content
	createLinkTitle: "Својства на врска",
	insertImageTitle: "Својства на слика",
	url: "URL-адреса:",
	text: "Опис:",
	target: "Цел:",
	set: "Постави",
	currentWindow: "Тековен прозорец",
	parentWindow: "Надреден прозорец",
	topWindow: "Краен прозорец",
	newWindow: "Нов прозорец"
//end v1.x content
});

