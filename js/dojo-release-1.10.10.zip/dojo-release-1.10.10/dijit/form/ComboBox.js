//>>built
define("dijit/form/ComboBox",["dojo/_base/declare","./ValidationTextBox","./ComboBoxMixin"],function(_1,_2,_3){
return _1("dijit.form.ComboBox",[_2,_3],{});
});
