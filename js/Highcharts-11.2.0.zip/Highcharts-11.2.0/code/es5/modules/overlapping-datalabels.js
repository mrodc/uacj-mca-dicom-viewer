/**
 * Highcharts JS v11.2.0 (2023-10-30)
 *
 * (c) 2009-2021 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */!function(e){"object"==typeof module&&module.exports?(e.default=e,module.exports=e):"function"==typeof define&&define.amd?define("highcharts/modules/overlapping-datalabels",["highcharts"],function(t){return e(t),e.Highcharts=t,e}):e("undefined"!=typeof Highcharts?Highcharts:void 0)}(function(e){"use strict";var t,o,a=e?e._modules:{};t="masters/modules/overlapping-datalabels.src.js",o=[a["Core/Globals.js"],a["Extensions/OverlappingDataLabels.js"]],a.hasOwnProperty(t)||(a[t]=(function(e,t){t.compose(e.Chart)}).apply(null,o),"function"==typeof CustomEvent&&window.dispatchEvent(new CustomEvent("HighchartsModuleLoaded",{detail:{path:t,module:a[t]}})))});//# sourceMappingURL=overlapping-datalabels.js.map